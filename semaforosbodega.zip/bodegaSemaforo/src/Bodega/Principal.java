package Bodega;

public class Principal {

	public static void main(String[] args) throws InterruptedException {
		
		Bodega bodega = new Bodega();
		Descargador descargador = new Descargador(bodega);
		Empacador empacador = new Empacador(bodega);
		
	}
	
}
