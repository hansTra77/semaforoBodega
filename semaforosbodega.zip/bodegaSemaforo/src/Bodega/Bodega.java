package Bodega;

import java.util.concurrent.Semaphore;

public class Bodega {
	
	private int capacidadBodegaActual;
	private int cantidadTipoUno;
	private int sinEmpacarTipoUno;
	private int cantidadTipoDos;
	private int sinEmpacarTipoDos;
	private Semaphore semaforoBodega;
	private Semaphore semaforoPaquete;
	private Object bloqueo;
	
	public Bodega() {
		
		
		this.cantidadTipoUno = 0;
		this.cantidadTipoDos = 0;
		this.capacidadBodegaActual = 200;
		this.semaforoBodega = new Semaphore(200);
		this.semaforoPaquete = new Semaphore(0);
		this.bloqueo = new Object();
		
	}
	
	public void descargarArticulo(int tipo) throws InterruptedException {
		
		int cantidad = (tipo == 1)?10:15;
		semaforoBodega.acquire(cantidad);
		
		synchronized (bloqueo) {
			
			if(tipo == 1) {
				
				cantidadTipoUno++;
				sinEmpacarTipoUno++;
				capacidadBodegaActual -= cantidad;
				
			} else {
				
				cantidadTipoDos++;
				sinEmpacarTipoDos++;
				capacidadBodegaActual -= cantidad;
				tipo = 2;
			}

			System.out.println("Agrego producto tipo: " + tipo);
			System.out.println("A: " + cantidadTipoUno + "    B: " + cantidadTipoDos);
			System.out.println("Espacio Bodega: " + capacidadBodegaActual);
			
		}
		
		if(sinEmpacarTipoUno >= 3 && sinEmpacarTipoDos >= 4) {
			
			sinEmpacarTipoUno -= 3;
			sinEmpacarTipoDos -= 4;
			semaforoPaquete.release();
			System.out.println("Se puede realizar un paquete");
			
		}
		
	}
	
	public void crearPaquete() throws InterruptedException {
		
		semaforoPaquete.acquire();
		
		synchronized (bloqueo) {
			
			cantidadTipoUno -= 3;
			cantidadTipoDos -= 4;
			capacidadBodegaActual += 90;
			
		}
		
		System.out.println("Se ha consumido exitosamente un paquete de 3 productos 1 y 4 productos 2");
		System.out.println("Espacio Bodega: " + capacidadBodegaActual);
		semaforoBodega.release(90);
		
	}
	
}
