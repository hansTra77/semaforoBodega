package Bodega;

import java.util.Random;

public class Descargador {
	
	public Descargador(final Bodega bodega) {
		
		Thread t = new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				Random r = new Random(1);
				
				try {
					
					while(true) {
						
						bodega.descargarArticulo(r.nextInt(2));
						Thread.sleep(3000);
						
					}
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				}
				
			}
			
		});
		
		t.start();
		
	}
		
}
